rootProject.name = "massas-dns"
